import { initializeApp } from "firebase/app";
import {
    getDoc,
    doc,
    getFirestore,
    setDoc,
    Firestore,
    collection,
    getDocs,
    DocumentData,
    deleteDoc,
} from "firebase/firestore";

export class FirebaseHandler {
    store: Firestore;

    constructor(options: object) {
        const firebaseConfig = options;
        const app = initializeApp(firebaseConfig);
        this.store = getFirestore(app);
    }

    public async push(data: any, path: string) {
        // WRITING
        const document = doc(this.store, path);
        await setDoc(document, data);
    }

    public async pull(path: string): Promise<DocumentData | undefined> {
        // READING
        const document = doc(this.store, path);
        const snapshot = await getDoc(document);
        if (snapshot.exists()) {
            return snapshot.data();
        }
        return undefined;
    }

    public async deleteCollection(path: string) {
        const querySnapshot = await getDocs(collection(this.store, path));

        querySnapshot.forEach(async (doc) => {
            await deleteDoc(doc.ref);
        });
    }
}
